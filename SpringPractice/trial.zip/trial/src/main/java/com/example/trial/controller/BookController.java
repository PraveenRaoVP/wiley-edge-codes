package com.example.trial.controller;

import com.example.trial.models.Book;
import com.example.trial.models.Management;
import com.example.trial.repository.BookRepository;
import com.example.trial.repository.ManagementRepository;
import com.example.trial.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;




@RestController
@RequestMapping("/books")
public class BookController {
    private final BookService bookService;

    @Autowired
    public BookController(BookService bookService) {
        this.bookService = bookService;
    }



    @GetMapping("")
    public String getAllBooks(Model model) {
        model.addAttribute("books", bookService.getAllBooks());
        return "books";
    }


    @PostMapping("/create")
    public String createBook(@ModelAttribute Book book) {
        bookService.createBook(book);
        return "redirect:/books";
    }

    @PostMapping("/add/{bookId}/author/{authorId}")
    public String addBookToAuthor(
            @PathVariable("bookId") Long bookId,
            @PathVariable("authorId") Long authorId
    ) {
        bookService.addBookToAuthor(bookId, authorId);
        return "redirect:/books";
    }

    @GetMapping("/books/{authorId}")
    public String getBooksByAuthorId(@PathVariable("authorId") Long authorId, Model model) {
        model.addAttribute("books", bookService.getBooksByAuthorId(authorId));
        return "books";
    }

    @PostMapping("/{id}/publish")
    public String publishBook(@PathVariable("id") Long bookId) {
        bookService.publishBook(bookId);
        return "redirect:/books";
    }
}
