package com.example.trial.controller;

import com.example.trial.models.Author;
import com.example.trial.service.AuthorService;
import com.example.trial.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/authors")
public class AuthorController {
    private final AuthorService authorService;
    private final BookService bookService;

    @Autowired
    public AuthorController(AuthorService authorService, BookService bookService) {
        this.authorService = authorService;
        this.bookService = bookService;
    }

    @GetMapping("")
    public String getAllAuthors(Model model) {
        model.addAttribute("authors", authorService.getAllAuthors());
        return "authors";
    }

    @PostMapping("/create")
    public String createAuthor(@ModelAttribute Author author) {
        authorService.createAuthor(author);
        return "redirect:/authors";
    }

    @GetMapping("/{id}/books")
    public String getBooksByAuthorId(@PathVariable("id") Long authorId, Model model) {
        model.addAttribute("books", bookService.getBooksByAuthorId(authorId));
        return "books";
    }

    @GetMapping("/{bookId}")
    public String getAuthorByBookId(@PathVariable("bookId") Long bookId, Model model) {
        model.addAttribute("authors", authorService.getAuthorsByBookId(bookId));
        return "authors";
    }


    @PostMapping("/{authorId}/books/{bookId}/add")
    public String addAuthorToBook(
            @PathVariable("authorId") Long authorId,
            @PathVariable("bookId") Long bookId
    ) {
        authorService.addAuthorToBook(authorId, bookId);
        return "redirect:/authors";
    }

    @PostMapping("/{authorId}/books/{bookId}/remove")
    public String removeAuthorFromBook(
            @PathVariable("authorId") Long authorId,
            @PathVariable("bookId") Long bookId
    ) {
        authorService.removeAuthorFromBook(authorId, bookId);
        return "redirect:/authors";
    }
}
